This script will read a Traktor collection file 
and convert all keys to the Camelot scale, commonly used by Mixed in Key.

It has only been tested on collection files created by Traktor Pro 2.6.1 and higher.

To use:
1. Extract files to the same folder as your collection file
2. Double click RUN.bat
3. BACKUP your collection file
4. Rename "collection_out.nml" to "collection.nml"
5. Boot Traktor
6. All converted keys will be in the "Key Text" column in the library.