This script will read a Traktor collection file 
and convert all keys to the Camelot scale, commonly used by Mixed in Key.

It has only been tested on collection files created by Traktor Pro 2.6.1 and higher.

Use on WINDOWS:
1. Extract files to the same folder as your collection file
2. Double click RUN.bat
3. BACKUP your collection file
4. Rename "collection_out.nml" to "collection.nml"
5. Boot Traktor
6. All converted keys will be in the "Key Text" column in the library.

Use on MAC*:
1. Extract files to the same folder as your collection file
2. Run the jar file (no output will appear other than the new collection file
3. BACKUP your collection file
4. Rename "collection_out.nml" to "collection.nml"
5. Boot Traktor
6. All converted keys will be in the "Key Text" column in the library.

*The steps are essentially the same. Only Windows can run *.bat files and the one included just shows extra output